/* VaporBarUS — Cookie consent banner
 * Storage key: cvus_cookie_consent
 * Choice schema: { essential: true, analytics: bool, marketing: bool, ts: <unix-ms> }
 * Custom event fired on save: 'cvus:consent-updated' with detail = choice
 * Listener pattern (for analytics pixels installed via Customer Events):
 *   window.addEventListener('cvus:consent-updated', e => { ... });
 *   const stored = JSON.parse(localStorage.getItem('cvus_cookie_consent') || 'null');
 */
(function () {
  'use strict';

  var STORAGE_KEY = 'cvus_cookie_consent';
  var EXPIRY_DAYS = 180; // banner re-prompts after 6 months

  function readChoice() {
    try {
      var raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return null;
      var parsed = JSON.parse(raw);
      if (!parsed || !parsed.ts) return null;
      var ageDays = (Date.now() - parsed.ts) / (1000 * 60 * 60 * 24);
      if (ageDays > EXPIRY_DAYS) return null;
      return parsed;
    } catch (e) {
      return null;
    }
  }

  function writeChoice(choice) {
    var payload = {
      essential: true,
      analytics: !!choice.analytics,
      marketing: !!choice.marketing,
      ts: Date.now()
    };
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
    } catch (e) { /* private mode etc. */ }
    window.dispatchEvent(new CustomEvent('cvus:consent-updated', { detail: payload }));
    return payload;
  }

  function init() {
    var banner = document.getElementById('cvus-cookie');
    if (!banner) return;

    // If a valid choice already exists, broadcast it for late-loading scripts and stay hidden.
    var existing = readChoice();
    if (existing) {
      window.dispatchEvent(new CustomEvent('cvus:consent-updated', { detail: existing }));
      return;
    }

    // Show the banner.
    banner.hidden = false;
    banner.setAttribute('aria-hidden', 'false');
    requestAnimationFrame(function () { banner.classList.add('is-open'); });

    var panel = document.getElementById('cvus-cookie-panel');
    var analyticsToggle = document.getElementById('cvus-cookie-analytics');
    var marketingToggle = document.getElementById('cvus-cookie-marketing');

    function close() {
      banner.classList.remove('is-open');
      banner.setAttribute('aria-hidden', 'true');
      setTimeout(function () { banner.hidden = true; }, 320);
    }

    banner.addEventListener('click', function (e) {
      var target = e.target.closest('[data-cvus-cookie]');
      if (!target) return;
      var action = target.getAttribute('data-cvus-cookie');

      if (action === 'accept') {
        writeChoice({ analytics: true, marketing: true });
        close();
      } else if (action === 'reject') {
        writeChoice({ analytics: false, marketing: false });
        close();
      } else if (action === 'manage') {
        var isOpen = !panel.hidden;
        panel.hidden = isOpen;
        panel.setAttribute('aria-hidden', String(isOpen));
        target.setAttribute('aria-expanded', String(!isOpen));
      } else if (action === 'save') {
        writeChoice({
          analytics: !!(analyticsToggle && analyticsToggle.checked),
          marketing: !!(marketingToggle && marketingToggle.checked)
        });
        close();
      }
    });
  }

  // Public helper: re-open the banner (e.g., from a footer "Manage cookies" link).
  window.cvusOpenCookieBanner = function () {
    try { localStorage.removeItem(STORAGE_KEY); } catch (e) {}
    var banner = document.getElementById('cvus-cookie');
    if (!banner) return;
    banner.hidden = false;
    banner.setAttribute('aria-hidden', 'false');
    requestAnimationFrame(function () { banner.classList.add('is-open'); });
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
